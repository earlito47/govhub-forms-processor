export class CrossValidator {
  validateCrossFields(data: Record<string, any>): any[] {
    return [];
  }
}
