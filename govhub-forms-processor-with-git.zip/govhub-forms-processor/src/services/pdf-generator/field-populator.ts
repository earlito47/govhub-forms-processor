export class FieldPopulator {
  // Implementation in index.ts
}
