export class Finalizer {
  // Implementation in index.ts
}
