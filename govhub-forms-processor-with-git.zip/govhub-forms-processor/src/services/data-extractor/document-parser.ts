export class DocumentParser {
  parseDocument(content: string, type: string): any {
    // Simplified parser
    return { raw: content };
  }
}
