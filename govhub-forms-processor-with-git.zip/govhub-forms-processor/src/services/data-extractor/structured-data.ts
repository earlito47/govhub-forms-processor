export class StructuredDataBuilder {
  buildCandidatePool(documents: any[]): Record<string, any> {
    return {};
  }
}
