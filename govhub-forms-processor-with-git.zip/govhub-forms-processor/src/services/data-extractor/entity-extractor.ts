export class EntityExtractor {
  extractEntities(text: string): any {
    return {};
  }
}
